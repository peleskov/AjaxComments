<?php
class acBranch extends xPDOSimpleObject {}