<?php
/**
 * Russian permissions Lexicon Entries for AjaxComments
 *
 * @package AjaxComments
 * @subpackage lexicon
 */
$_lang['ajaxcomments_save'] = 'Permission for save/update data.';