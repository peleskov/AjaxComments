<?php
require_once (dirname(__DIR__) . '/acbranch.class.php');
class acBranch_mysql extends acBranch {}