<?php
class acMessage extends xPDOSimpleObject {}