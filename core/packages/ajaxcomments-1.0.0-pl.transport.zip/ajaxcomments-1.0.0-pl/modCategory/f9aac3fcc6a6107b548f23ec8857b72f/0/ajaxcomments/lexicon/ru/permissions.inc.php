<?php
/**
 * English permissions Lexicon Entries for AjaxComments
 *
 * @package AjaxComments
 * @subpackage lexicon
 */
$_lang['ajaxcomments_save'] = 'Разрешает создание/изменение данных.';