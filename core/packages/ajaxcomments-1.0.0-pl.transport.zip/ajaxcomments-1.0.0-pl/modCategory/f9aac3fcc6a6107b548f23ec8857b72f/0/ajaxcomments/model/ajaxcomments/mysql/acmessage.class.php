<?php
require_once (dirname(__DIR__) . '/acmessage.class.php');
class acMessage_mysql extends acMessage {}