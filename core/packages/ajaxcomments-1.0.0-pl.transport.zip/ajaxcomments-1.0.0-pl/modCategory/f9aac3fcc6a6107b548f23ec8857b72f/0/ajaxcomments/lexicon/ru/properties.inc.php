<?php

$_lang['ajaxcomments_prop_limit'] = 'Ограничение вывода Предметов на странице.';
$_lang['ajaxcomments_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['ajaxcomments_prop_sortby'] = 'Поле сортировки.';
$_lang['ajaxcomments_prop_sortdir'] = 'Направление сортировки.';
$_lang['ajaxcomments_prop_tpl'] = 'Чанк оформления каждого ряда Предметов.';
$_lang['ajaxcomments_prop_toPlaceholder'] = 'Если указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
