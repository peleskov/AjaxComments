--------------------
AjaxComments
--------------------
Author: Sergei Peleskov <info@s1temaker.ru>
--------------------

A Comments Extra for MODx Revolution.