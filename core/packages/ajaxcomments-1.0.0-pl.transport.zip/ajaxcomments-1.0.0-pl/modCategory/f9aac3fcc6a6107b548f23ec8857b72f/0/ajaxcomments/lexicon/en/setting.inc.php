<?php

$_lang['area_ajaxcomments_main'] = 'Main';

$_lang['setting_ajaxcomments_some_setting'] = 'Some setting';
$_lang['setting_ajaxcomments_some_setting_desc'] = 'This is description for some setting';